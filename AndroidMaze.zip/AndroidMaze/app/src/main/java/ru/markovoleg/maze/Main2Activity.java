package ru.markovoleg.maze;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
    public void startActivity(View v) {
        switch (v.getId()) {
            case R.id.button:
                Intent i = new Intent(v.getContext(), MainActivity.class);
                startActivity(i);
                break;
        }
    }
    public void startActivity0(View v) {
        switch (v.getId()) {
            case R.id.button2:
                Intent i = new Intent(v.getContext(), Main4Activity.class);
                startActivity(i);
                break;
        }
    }
}
