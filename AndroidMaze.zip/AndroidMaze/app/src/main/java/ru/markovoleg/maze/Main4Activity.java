package ru.markovoleg.maze;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Main4Activity extends AppCompatActivity {
public static boolean ifLevel;
public static int f = 0;
    public static SharedPreferences sPref;
    public static SharedPreferences.Editor ed;
    public static final String SAVED_TEXT = "save1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GameManager.f = 5;
        setContentView(R.layout.activity_main4);
    }
    public void startActivity4(View v) {
        switch (v.getId()) {
            case R.id.button5:
                Intent i = new Intent(v.getContext(), Main2Activity.class);
                startActivity(i);
                break;
        }
    }

    public void b1(View view) {
        f = 5;
        GameManager.n = 1;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }

    public void b2(View view) {
        f = 10;
        GameManager.n = 2;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b3(View view) {
        f = 15;
        GameManager.n = 3;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b4(View view) {
        f = 20;
        GameManager.n = 4;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b5(View view) {
        f = 25;
        GameManager.n = 5;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b6(View view) {
        f = 30;
        GameManager.n = 6;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b7(View view) {
        f = 35;
        GameManager.n = 7;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b8(View view) {
        f = 40;
        GameManager.n = 8;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b9(View view) {
        f = 45;
        GameManager.n = 9;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b10(View view) {

        f = 50;
        GameManager.n = 10;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b11(View view) {
        f = 55;
        GameManager.n = 11;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b12(View view) {
        f = 60;
        GameManager.n = 12;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b13(View view) {
        f = 65;
        GameManager.n = 13;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b14(View view) {
        f = 70;
        GameManager.n = 14;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b15(View view) {
        f = 75;
        GameManager.n = 15;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b16(View view) {
        f = 80;
        GameManager.n = 16;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b17(View view) {
        f = 85;
        GameManager.n = 17;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
    public void b18(View view) {
        f = 90;
        GameManager.n = 18;
        ifLevel = true;
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }
}
