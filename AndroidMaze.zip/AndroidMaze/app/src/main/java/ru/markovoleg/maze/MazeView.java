package ru.markovoleg.maze;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

public class MazeView extends View {
    private GameManager gameManager;
    public MazeView(Context context, AttributeSet attrs) {

        super(context, attrs);
        this.gameManager = MainActivity.gameManager;

        gameManager.setView(this);



    }

    @Override
    protected void onDraw(Canvas canvas) {
        gameManager.draw(canvas);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        gameManager.setScreenSize(w,h);
    }
}
