package ru.markovoleg.maze;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.PersistableBundle;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.AbstractQueue;
import java.util.Timer;
import java.util.TimerTask;

import static ru.markovoleg.maze.R.id.textView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onStart() {
        super.onStart();
        if (Main4Activity.ifLevel == false) {
            sPref = getPreferences(MODE_PRIVATE);
            String savedText = sPref.getString(SAVED_TEXT, "");
            if(savedText != "") {
                int st = Integer.parseInt(savedText);
                GameManager.create(st * 5);
                GameManager.n = st;
            } else {
                int st = 5;
                GameManager.create(st * 5);
                GameManager.n = st;
            }
        } else {
            GameManager.create(Main4Activity.f);
        }

    }
    public TextView tv;
    boolean ifFinish = false;
    public static SharedPreferences sPref;
    public static SharedPreferences.Editor ed;
    public static final String SAVED_TEXT = "save";
    private MazeView view;
    public static int n1;
    private GestureDetector gestureDetector;
    public static GameManager gameManager = new GameManager();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast toast = Toast.makeText(getApplicationContext(),
                "Вам надо пройти красным квадратом до зеленого.", Toast.LENGTH_SHORT);
        toast.show();

        ifFinish = false;
        tv = (TextView) findViewById(R.id.text1) ;

        Timer timer = new Timer();
        long delay = 0;
        long period = 1;
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tv.setText("LEVEL " + GameManager.n);
                        if (Main4Activity.ifLevel == false) {
                            sPref = getPreferences(MODE_PRIVATE);
                            ed = sPref.edit();
                            ed.putString(SAVED_TEXT, String.valueOf(GameManager.n));
                            ed.commit();
                        }
                    }
                });
            }
        },delay,period);
        gestureDetector = new GestureDetector(this, gameManager);
    }
    @Override
    protected void onStop() {
        super.onStop();

    }



    public void startActivity1(View v) {
        switch (v.getId()) {
            case R.id.button3:
                if(Main4Activity.ifLevel == true) {
                    sPref = getPreferences(MODE_PRIVATE);
                    String savedText = sPref.getString(SAVED_TEXT, "");
                    int st = Integer.parseInt(savedText);
                    GameManager.create(st * 5);
                    n1 = st;
                    GameManager.n = n1;
                    Intent i = new Intent(MainActivity.this, Main2Activity.class);
                    startActivity(i);
                    Main4Activity.ifLevel = false;
                } else {
                    Intent i = new Intent(MainActivity.this, Main3Activity.class);
                    startActivity(i);
                }
                break;
        }
    }



    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return gestureDetector.onTouchEvent(event);
    }

    public void startActivity5(View view) {
        if(Main4Activity.ifLevel == true) {
            sPref = getPreferences(MODE_PRIVATE);
            String savedText = sPref.getString(SAVED_TEXT, "");
            int st = Integer.parseInt(savedText);
            GameManager.create(st * 5);
            n1 = st;
            GameManager.n = n1;
            Main4Activity.ifLevel = false;
        }
        Intent i = new Intent(MainActivity.this, Main2Activity.class);
        startActivity(i);
    }
}
