package ru.markovoleg.maze;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.TextView;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Timer;
import java.util.TimerTask;

public class Main3Activity extends AppCompatActivity {
TextView tv1;
    public static SharedPreferences sPref;
    public static final String SAVED_TEXT = "saved_text";
 public static SharedPreferences prefs;
    public static int record = 0;

    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        tv1 = (TextView) findViewById(R.id.textView2) ;

        sPref = getPreferences(MODE_PRIVATE);
        String savedText = sPref.getString(SAVED_TEXT, "");
        if(savedText != "") {
            record = Integer.parseInt(savedText);
        } else {
            record = 0;
        }
                            if (GameManager.n > record) {
                                record = GameManager.n;
                            }
                            tv1.setText("YOUR SCORE IS " + GameManager.n + " (RECORD: " + record + ")");
                            GameManager.n = 1;
                            GameManager.f = 5;
                    }





    public void startActivity3(View v) {
        switch (v.getId()) {
            case R.id.button4:
                Intent i = new Intent(v.getContext(), Main2Activity.class);
                startActivity(i);
                sPref = getPreferences(MODE_PRIVATE);
                Editor ed = sPref.edit();
                ed.putString(SAVED_TEXT, String.valueOf(record));
                ed.commit();

                break;
        }
    }
}
